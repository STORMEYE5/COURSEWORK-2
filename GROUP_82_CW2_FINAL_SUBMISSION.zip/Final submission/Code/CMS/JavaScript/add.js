// let btnclick;

// window.onload = function(){start();}

// function start(){
//     // let request = new XMLHttpRequest();
//     // request.open('POST', true);
//     // request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

//     // btnclick = document.getElementById("btn_submit").addEventListener('click', data_submit)

    
//     // request.send(coded_data);
    
// }

// $.ajax({
//     type: "POST",
//     url: "add_backend.php",

//     success: function(){
//         alert("OK");
//     }
// });
// function data_submit(){
//     location.href = "add_backend.php"
// }
